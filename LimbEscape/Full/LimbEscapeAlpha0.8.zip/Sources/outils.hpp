

#ifndef TOOL
#define TOOL



namespace utils
{

    std::string ConvertionFltString(float nombre );


}



#endif // TOOL
